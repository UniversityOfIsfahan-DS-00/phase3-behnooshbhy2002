#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

namespace Ui {
class MainWindow;
}
class stack
{
  private :
      int top;
      QString arr[50];
  public :
      stack()
      {
          top=-1;
      }
      void push(QString str )
      {
          top++;
          arr[top]=str;
      }
      QString peek()
      {
          return arr[top];
      }
      QString pop()
      {
          if(top!=-1){
            int t=top;
            top--;
            return arr[t];
          }

      }
      bool isEmpty()
      {
          if(top==-1)
            return true;
          return false;
      }

};
class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:


    void on_btn_parantez_op_clicked();

    void on_btn_parantez_clo_clicked();

    void on_btn_pow_clicked();

    void on_btn_div_clicked();

    void on_btn_7_clicked();

    void on_btn_8_clicked();

    void on_btn_9_clicked();

    void on_btn_mul_clicked();

    void on_btn_4_clicked();

    void on_btn_5_clicked();

    void on_btn_6_clicked();

    void on_btn_del_clicked();

    void on_btn_1_clicked();

    void on_btn_2_clicked();

    void on_btn_3_clicked();

    void on_btn_add_clicked();

    void on_btn_0_clicked();

    void on_btn_pre_clicked();

    void on_btn_eq_clicked();

    void on_btn_ce_clicked();

    void on_btn_c_clicked();

    void on_btn_history_clicked();


private:

    Ui::MainWindow *ui;
    bool isOperators(QString digit);
    bool IsNumber(QString digit);
    bool IsError(QString str[]);
    bool control_error(QString str[]);

    void Postfix_To_Infix(QString arr[]);
    void solve(QString arr[]);
    int precedence(QString operate);
    void Infix_To_Postfix(QString arr[]);
    void convert_charTostring(QString str[]);
};

#endif // MAINWINDOW_H
