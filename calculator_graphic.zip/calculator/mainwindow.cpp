#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
int step=0;
bool History=false;
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_btn_parantez_op_clicked()
{
    ui->textEdit->insertPlainText("(");
}


void MainWindow::on_btn_parantez_clo_clicked()
{
    ui->textEdit->insertPlainText(")");
}

void MainWindow::on_btn_pow_clicked()
{
    ui->textEdit->insertPlainText("^");
}

void MainWindow::on_btn_div_clicked()
{
    ui->textEdit->insertPlainText("/");
}

void MainWindow::on_btn_7_clicked()
{
    ui->textEdit->insertPlainText("7");
}

void MainWindow::on_btn_8_clicked()
{
    ui->textEdit->insertPlainText("8");
}

void MainWindow::on_btn_9_clicked()
{
    ui->textEdit->insertPlainText("9");
}

void MainWindow::on_btn_mul_clicked()
{
    ui->textEdit->insertPlainText("*");
}

void MainWindow::on_btn_4_clicked()
{
    ui->textEdit->insertPlainText("4");
}

void MainWindow::on_btn_5_clicked()
{
    ui->textEdit->insertPlainText("5");
}

void MainWindow::on_btn_6_clicked()
{
    ui->textEdit->insertPlainText("6");
}

void MainWindow::on_btn_del_clicked()
{
    ui->textEdit->insertPlainText("-");
}

void MainWindow::on_btn_1_clicked()
{
    ui->textEdit->insertPlainText("1");
}

void MainWindow::on_btn_2_clicked()
{
    ui->textEdit->insertPlainText("2");
}

void MainWindow::on_btn_3_clicked()
{
    ui->textEdit->insertPlainText("3");
}

void MainWindow::on_btn_add_clicked()
{
    ui->textEdit->insertPlainText("+");
}

void MainWindow::on_btn_0_clicked()
{
    ui->textEdit->insertPlainText("0");
}

void MainWindow::on_btn_pre_clicked()
{
    ui->textEdit->insertPlainText(".");
}

void MainWindow::on_btn_eq_clicked()
{
    QString str = ui->textEdit->toPlainText();
    ui->textEdit->insertPlainText("\n=");
    QString arr[str.length()+1];
    //QMessageBox m;
    ///////////////

    for(int i = 0; i < str.length(); i++){
        arr[i] = static_cast<QString>(str.at(i));

    }
    ui->show_history->clear();
    if(control_error(arr))
        ui->textEdit->insertPlainText("Error");
    else{
        ui->show_history->insertPlainText("\n\nStep 0 : "+str+"\n");
        ui->show_history->toPlainText();
        convert_charTostring(arr);
    }

}

void MainWindow::on_btn_ce_clicked()
{

    QString text = ui->textEdit->toPlainText();
    //int n = text.size();
    ui->textEdit->clear();
    text = text.remove(text.length()-1 , 1);
    ui->textEdit->insertPlainText(text);
    ui->show_history->clear();
    step=0;
}

void MainWindow::on_btn_c_clicked()
{
    ui->textEdit->clear();
    ui->show_history->clear();
    step=0;
}

bool MainWindow::isOperators(QString digit)
{
    int i=0;
        QString operators[6]={"+","-","*","/","^"};
         while(operators[i]!="\0")
         {
             if(operators[i]==digit)
                return true;
            i++;
         }
         return false;
}

bool MainWindow::IsNumber(QString digit)
{
    if(digit>="0" && digit<="9")
        return true;
    return false;
}

bool MainWindow::IsError(QString str[])
{
    stack parenthesis;
    int i=0 , temp;
    bool flag=false;
    while(str[i]!="\0")
    {

       if(!( isOperators(str[i]) || str[i]=="(" || str[i]==")" || str[i]=="." || IsNumber(str[i])))
           return true;

       if(str[i]==")" && parenthesis.isEmpty())
           return true;

       else if(str[i]=="(")
       {
           if(str[i+1]==")")
               return true;

           parenthesis.push("(");
       }

       else if(str[i]==")")
           parenthesis.pop();

       else if(isOperators(str[i]) && isOperators(str[i+1]))
           return true;

       else if( (str[i]=="." && str[i+1]==".") || ( str[i]=="." && !IsNumber(str[i-1]) && !IsNumber(str[i+1])))
           return true;

       else if(str[i]=="0" && str[i-1]=="/")
       {

           if(str[i+1]!=".")
              return true;
           else
           {
               temp=i+2;

               while(!isOperators(str[temp])){

                   if(str[temp]=="0")
                   {
                       flag=true;
                   }
                   else if(IsNumber(str[temp]) && str[temp]!="0")
                   {
                       return false;
                   }
                   temp++;

               }
               if(flag)
                   return true;
           }
       }
       else if(isOperators(str[i]))
       {

           bool prob = ( (str[i]=="-" || str[i]=="+") && (IsNumber(str[i+1])) );

           if(  !((str[i-1]==")"||str[i+1]=="(")
             || ( ( (IsNumber(str[i-1])) || str[i-1]=="." )
              && ( (IsNumber(str[i+1]) ) || str[i+1]==".")) || prob ) )
              return true;

       }


       i++;
    }
      if(parenthesis.isEmpty())
        return false;

   return true;
}

bool MainWindow::control_error(QString str[])
{
    if(IsError(str))
       return true;
    else
       return false;
}

void MainWindow::Postfix_To_Infix(QString arr[])
{
    stack stk;
        QString num1 , num2;
        int i=0;
        while(arr[i]!="\0")
        {

            if(isOperators(arr[i]))
            {
                num1 = stk.pop();
                num2 = stk.pop();
                stk.push("(" + num2 + arr[i] + num1 + ")");
            }
            else
            {
                 stk.push(arr[i]);
            }
            i++;
        }
        step++;
        QString step_str;
        step_str.setNum(step);
        ui->show_history->insertPlainText("Step "+step_str+" : "+stk.pop()+"\n");
        ui->show_history->toPlainText();
       // cout<<"Step "<<step<<" : "<<stk.pop()<<endl;
}

void MainWindow::solve(QString arr[])
{
    int i=0;
    double number1 , number2 , result;
    QString num1 , num2 , res;
    stack stk;

      while(arr[i]!="\0")
      {
          if(isOperators(arr[i]))
          {
              num1 = stk.pop();
              num2 = stk.pop();
              number1= num1.toDouble();
              number2= num2.toDouble();

                if(arr[i]=="+")
                {
                    result = number2 + number1;

                }
                else if(arr[i]=="-")
                {
                    result = number2 - number1;

                }
                else if(arr[i]=="*")
                {
                    result = number2 * number1;

                }
                else if(arr[i]=="/")
                {
                    result = number2 / number1;

                }
                else
                {
                    result = pow(number2 , number1);

                }

               res = QString::number(result);


                    arr[i]=res;
                    int temp=i;
                    while(arr[temp]!="\0")
                    {
                      arr[temp-2]="\0";
                      arr[temp-1]="\0";
                      arr[temp-2]=arr[temp];
                      arr[temp]="\0";
                      temp++;
                    }
                    Postfix_To_Infix(arr);
                    i=i-2;

                stk.push(res);

          }
          else
          {
              stk.push(arr[i]);
          }

          i++;
      }
      ui->textEdit->insertPlainText(stk.pop());
      ui->textEdit->toPlainText();
      //cout<<"result : "<<stk.pop();
}

int MainWindow::precedence(QString operate)
{
    if(operate=="^")
        return 3;
    else if(operate=="*" || operate=="/")
        return 2;
    else if(operate=="+" || operate=="-")
        return 1;
}

void MainWindow::Infix_To_Postfix(QString arr[])
{
        stack s;
        int i=0 , n=-1;

          while(arr[i]!="\0")
          {

              if(!isOperators(arr[i]) && arr[i]!="(" && arr[i]!=")")
              {
                  arr[++n]=arr[i];
              }
              else if(arr[i]=="(")
              {
                  s.push(arr[i]);
              }
              else if(arr[i]==")")
              {
                  while(!s.isEmpty() && s.peek()!="(")
                  {
                      arr[++n]=s.pop();
                  }
                  if(!s.isEmpty() && s.peek()!="(")
                    return;
                  else
                    s.pop();
              }
              else if(arr[i]!="^")
              {

                   while(!s.isEmpty() && precedence(arr[i]) <= precedence(s.peek()))
                     arr[++n]=s.pop();

                  s.push(arr[i]);
              }
              else {

                    while(!s.isEmpty() && precedence(arr[i]) < precedence(s.peek()))
                     arr[++n]=s.pop();

                  s.push(arr[i]);

              }
              i++;
          }

          while(!s.isEmpty())
          {
              arr[++n]=s.pop();
          }
          arr[++n]="\0";


          solve(arr);
}

void MainWindow::convert_charTostring(QString str[])
{
    int i=0 , counter=0 ;
    QString arr[1000];
      while(str[i]!="\0"){

         if(str[i]=="-" && ( i==0 || str[i-1]=="(" ))
         {
             arr[counter]="-1";
             arr[++counter]="*";

         }
         else if(str[i]!="+" || i!=0){

            arr[counter]=str[i];

             if( IsNumber(str[i]) || str[i]=="."){
               i++;
               while ( IsNumber(str[i]) || str[i]=="." ){
                  arr[counter] += str[i];
                  i++;
               }

               i--;

             }

         }

         i++;
         counter++;
      }

      Infix_To_Postfix(arr);

}

void MainWindow::on_btn_history_clicked()
{
    History = true;
}
